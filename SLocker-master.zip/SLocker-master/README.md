# SLocker: Android ransomware

<img src="https://blog.trendmicro.com/trendlabs-security-intelligence/files/2017/06/SLocker2.png" width="250" />

The SLocker family is one of the oldest mobile lock screen and file-encrypting ransomware and used to impersonate law enforcement agencies to convince victims to pay their ransom.

See more in the [Trendmicro analysis](http://blog.trendmicro.com/trendlabs-security-intelligence/slocker-mobile-ransomware-starts-mimicking-wannacry/)

## Where does this code come from?

This code was obtained by reversing a sample of SLocker. ***It’s not the original source code***

## Disclaimer

***Note: SLocker is intended to be used for security research purposes only. Any other use is not the responsibility of the developer(s). Be sure that you understand and are complying with the laws in your area. In other words, don't be stupid, don't be an asshole, and use it responsibly and legally.***
